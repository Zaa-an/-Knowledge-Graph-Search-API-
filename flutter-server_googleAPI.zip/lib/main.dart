import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const KnowledgeGraphApp());
}

class KnowledgeGraphApp extends StatelessWidget {
  const KnowledgeGraphApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Google Knowledge Graph Search',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
      ),
      home: const SearchEntityPage(),
    );
  }
}

class ApiConfig {
  // TODO: GANTI DENGAN URL DOMAIN INFINITYFREE MILIKMU SENDIRI
  static const String serverSaveUrl =
      'https://rezjackwi.gamer.gd/api_google/save_translation.php';
  static const String serverListUrl =
      'https://rezjackwi.gamer.gd/api_google/list_translation.php';

  // TODO: MASUKKAN API KEY KNOWLEDGE GRAPH YANG KAMU BUAT DI GOOGLE CLOUD CONSOLE
  static const String googleApiKey = 'AIzaSyDONslTHnHoOaZRm9sfGAOCMXSUcANfvWI';
}

class EntityModel {
  final String id;
  final String googleId;
  final String name;
  final String type;
  final String description;
  final String url;
  final String imageUrl;

  EntityModel({
    required this.id,
    required this.googleId,
    required this.name,
    required this.type,
    required this.description,
    required this.url,
    required this.imageUrl,
  });

  Map<String, dynamic> toServerJson() {
    return {
      'google_id': googleId,
      'nama_entitas': name,
      'tipe_entitas': type,
      'deskripsi_singkat': description,
      'url_sumber': url,
      'url_gambar': imageUrl.isEmpty ? null : imageUrl,
    };
  }

  factory EntityModel.fromServerJson(Map<String, dynamic> json) {
    return EntityModel(
      id: json['id']?.toString() ?? '',
      googleId: json['google_id']?.toString() ?? '',
      name: json['nama_entitas']?.toString() ?? 'Tanpa Nama',
      type: json['tipe_entitas']?.toString() ?? 'Entitas',
      description: json['deskripsi_singkat']?.toString() ?? '',
      url: json['url_sumber']?.toString() ?? '',
      imageUrl: json['url_gambar']?.toString() ?? '',
    );
  }
}

class SearchEntityPage extends StatefulWidget {
  const SearchEntityPage({super.key});

  @override
  State<SearchEntityPage> createState() => _SearchEntityPageState();
}

class _SearchEntityPageState extends State<SearchEntityPage> {
  final TextEditingController searchController = TextEditingController();

  List<EntityModel> searchResults = [];
  List<EntityModel> savedEntities = [];

  bool isLoadingSearch = false;
  bool isSavingData = false;
  bool isLoadingSavedData = false;

  @override
  void initState() {
    super.initState();
    loadEntitiesFromServer();
  }

  Future<void> searchEntity() async {
    final String query = searchController.text.trim();

    if (query.isEmpty) {
      showMessage('Ketik kata kunci pencarian dahulu.');
      return;
    }

    setState(() {
      isLoadingSearch = true;
      searchResults = [];
    });

    try {
      final Uri uri = Uri.parse(
          'https://kgsearch.googleapis.com/v1/entities:search?query=$query&key=${ApiConfig.googleApiKey}&limit=1&indent=true');

      final http.Response response = await http.get(uri);

      if (response.statusCode != 200) {
        throw Exception('Gagal API Google: Status ${response.statusCode}');
      }

      final Map<String, dynamic> decoded = jsonDecode(response.body);
      final List<dynamic> itemList = decoded['itemListElement'] ?? [];

      if (itemList.isEmpty) {
        showMessage('Informasi tidak ditemukan di Google Knowledge Graph.');
        return;
      }

      final dynamic itemResult = itemList[0]['result'];
      final String googleId = itemResult['@id'] ?? '';
      final String name = itemResult['name'] ?? 'Tanpa Nama';

      final List<dynamic> types = itemResult['@type'] ?? [];
      final String type = types.isNotEmpty ? types.first.toString() : 'Entitas';

      final dynamic detailedDesc = itemResult['detailedDescription'];
      final String description = detailedDesc != null
          ? detailedDesc['articleBody'] ?? ''
          : (itemResult['description'] ?? 'Tidak ada deskripsi.');
      final String url = detailedDesc != null ? detailedDesc['url'] ?? '' : '';

      final dynamic imageNode = itemResult['image'];
      final String imageUrl =
          imageNode != null ? imageNode['contentUrl'] ?? '' : '';

      final EntityModel newEntity = EntityModel(
        id: '',
        googleId: googleId,
        name: name,
        type: type,
        description: description,
        url: url,
        imageUrl: imageUrl,
      );

      setState(() {
        searchResults = [newEntity];
      });

      showMessage('Data ditemukan!');
    } catch (e) {
      showMessage('Error Pencarian: $e');
    } finally {
      setState(() {
        isLoadingSearch = false;
      });
    }
  }

  Future<void> saveToServer(EntityModel item) async {
    setState(() {
      isSavingData = true;
    });

    try {
      final Uri uri = Uri.parse(ApiConfig.serverSaveUrl);
      final http.Response response = await http.post(
        uri,
        headers: {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode(item.toServerJson()),
      );

      if (response.statusCode != 200) {
        throw Exception('Server mengembalikan status ${response.statusCode}');
      }

      final Map<String, dynamic> decoded = jsonDecode(response.body);

      if (decoded['success'] == true) {
        showMessage('Berhasil disimpan ke MySQL InfinityFree!');
        setState(() {
          searchResults = [];
        });
        await loadEntitiesFromServer();
      } else {
        throw Exception(decoded['message'] ?? 'Respons server gagal');
      }
    } catch (e) {
      showMessage('Gagal menyimpan ke server: $e');
    } finally {
      setState(() {
        isSavingData = false;
      });
    }
  }

  Future<void> loadEntitiesFromServer() async {
    setState(() {
      isLoadingSavedData = true;
    });

    try {
      final Uri uri = Uri.parse(ApiConfig.serverListUrl);
      final http.Response response = await http.get(uri);

      if (response.statusCode != 200) {
        throw Exception('Server mengembalikan status ${response.statusCode}');
      }

      final Map<String, dynamic> decoded = jsonDecode(response.body);

      if (decoded['success'] == true) {
        final dynamic dataList = decoded['data'];
        if (dataList is List) {
          setState(() {
            savedEntities = dataList
                .whereType<Map<String, dynamic>>()
                .map(EntityModel.fromServerJson)
                .toList();
          });
        }
      } else {
        throw Exception(decoded['message'] ?? 'Gagal memuat');
      }
    } catch (e) {
      showMessage('Gagal sinkronisasi server: $e');
    } finally {
      setState(() {
        isLoadingSavedData = false;
      });
    }
  }

  void showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 4)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Knowledge Graph Search'),
        backgroundColor: Colors.indigo.shade100,
        actions: [
          IconButton(
            icon: const Icon(Icons.sync),
            tooltip: 'Sinkronisasi Server',
            onPressed: loadEntitiesFromServer,
          )
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    TextField(
                      controller: searchController,
                      decoration: const InputDecoration(
                        labelText: 'Cari Entitas Informasi Global',
                        hintText:
                            'Contoh: Albert Einstein, Indonesia, Google...',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: isLoadingSearch ? null : searchEntity,
                        icon: const Icon(Icons.search),
                        label: Text(isLoadingSearch
                            ? 'Menghubungi Google...'
                            : 'Cari Informasi'),
                      ),
                    )
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            if (searchResults.isNotEmpty) ...[
              Card(
                color: Colors.green.shade50,
                elevation: 2,
                shape: RoundedRectangleBorder(
                    side: BorderSide(color: Colors.green.shade300),
                    borderRadius: BorderRadius.circular(8)),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (searchResults[0].imageUrl.isNotEmpty) ...[
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            searchResults[0].imageUrl,
                            height: 150,
                            width: double.infinity,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) =>
                                const SizedBox(),
                          ),
                        ),
                        const SizedBox(height: 12),
                      ],
                      Row(
                        mainAxisAlignment: MainAxisAlignment
                            .spaceBetween, // <-- SUDAH DIPERBAIKI
                        children: [
                          Expanded(
                            child: Text(
                              searchResults[0].name,
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                  color: Colors.indigo),
                            ),
                          ),
                          Chip(
                            label: Text(searchResults[0].type),
                            backgroundColor: Colors.indigo.shade50,
                          )
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(searchResults[0].description,
                          style: const TextStyle(fontSize: 14)),
                      const Divider(height: 24),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: isSavingData
                              ? null
                              : () => saveToServer(searchResults[0]),
                          icon: const Icon(Icons.cloud_upload),
                          label: Text(isSavingData
                              ? 'Mengirim Data...'
                              : 'Simpan ke Database InfinityFree'),
                          style: FilledButton.styleFrom(
                            // <-- SUDAH DIPERBAIKI
                            backgroundColor: Colors.green.shade700,
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],
            const Text(
              'Riwayat Informasi Tersimpan di MySQL',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 8),
            if (isLoadingSavedData)
              const Padding(
                // <-- SUDAH DIPERBAIKI
                padding: EdgeInsets.all(24),
                child: Center(
                  child: CircularProgressIndicator(),
                ),
              )
            else if (savedEntities.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(
                      child: Text(
                          'Database server kosong atau koneksi terhadang.')),
                ),
              )
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: savedEntities.length,
                itemBuilder: (context, index) {
                  final item = savedEntities[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      leading: item.imageUrl.isNotEmpty
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(4),
                              child: Image.network(
                                item.imageUrl,
                                width: 50,
                                height: 50,
                                fit: BoxFit.cover,
                                errorBuilder: (c, e, s) =>
                                    const Icon(Icons.broken_image),
                              ),
                            )
                          : const CircleAvatar(child: Icon(Icons.info)),
                      title: Text(item.name,
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Tipe: ${item.type}',
                              style: const TextStyle(
                                  color: Colors.blueGrey,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12)),
                          Text(item.description,
                              maxLines: 2, overflow: TextOverflow.ellipsis),
                        ],
                      ),
                      isThreeLine: true,
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}
